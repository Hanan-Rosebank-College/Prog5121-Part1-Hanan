package com.mycompany.prog5121part1hannah;

import java.util.Scanner;
import java.util.ArrayList;

// class to store user information
class Person{
    private String userName;
    private String passWord;
    private String phoneNumber;
    private String firstName;
    private String lastName;
    
    // constructor
    public Person(String userName, String passWord, String phoneNumber, String firstName, String lastName){
        this.userName = userName;
        this.passWord = passWord;
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    // getter methods
    public String getUserName(){ return userName; }
    public String getPassWord(){ return passWord; }
    public String getPhoneNumber(){ return phoneNumber; }
    public String getFirstName(){ return firstName; }
    public String getLastName(){ return lastName; }
}

public class Prog5121Part1Hannah {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Person> people = new ArrayList<>();
        
        System.out.println("\n=================================");
        System.out.println("       WELCOME TO MY APP FOR 2026");
        System.out.println("=================================");
        
        while(true){
            System.out.println("\n1. Register the user");
            System.out.println("2. Logging in");
            System.out.println("3. Exit");
            System.out.print("Choose: ");
            
            int pick = sc.nextInt();
            sc.nextLine();
            
            if(pick == 1){
                System.out.println("\n--- CREATE ACCOUNT ---");
                
                System.out.print("First name: ");
                String firstName = sc.nextLine();
                
                System.out.print("Last name: ");
                String lastName = sc.nextLine();
                
                System.out.print("Make username (needs _ and max 5 letters): ");
                String userName = sc.nextLine();
                
                // check username format
                if(userName.contains("_") && userName.length() <= 5){
                    System.out.println("Username successfully captured!");
                }
                else{
                    System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
                    continue;
                }
                
                System.out.print("Make password (8+ chars, 1 capital, 1 number, 1 special): ");
                String passWord = sc.nextLine();
                
                boolean hasCapital = false;
                boolean hasNumber = false;
                boolean hasSpecial = false;
                String specialCharacters = "!@#$%^&*()";
                
                // loop through password to check each character
                for(int x = 0; x < passWord.length(); x++){
                    char c = passWord.charAt(x);
                    if(Character.isUpperCase(c)) hasCapital = true;
                    if(Character.isDigit(c)) hasNumber = true;
                    if(specialCharacters.indexOf(c) >= 0) hasSpecial = true;
                }
                
                // validate password strength
                if(passWord.length() >= 8 && hasCapital && hasNumber && hasSpecial){
                    System.out.println("Password successfully captured!");
                }
                else{
                    System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
                    continue;
                }
                
                System.out.print("Phone number  ");
                String phoneNumber = sc.nextLine();
                
                // check south african phone number
                if(phoneNumber.startsWith("+27") && phoneNumber.length() == 12){
                    System.out.println("Cell phone number successfully added!");
                }
                else{
                    System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
                    continue;
                }
                
                // see if username already exists
                boolean userNameTaken = false;
                for(Person p : people){
                    if(p.getUserName().equals(userName)){
                        userNameTaken = true;
                        break;
                    }
                }
                
                if(userNameTaken){
                    System.out.println("Username taken. Try another.");
                    continue;
                }
                
                // save new user
                people.add(new Person(userName, passWord, phoneNumber, firstName, lastName));
                System.out.println("\nAccount made!");
                System.out.println("Hi " + userName + "! Now you can Login.\n");
                
                // auto login after registration
                System.out.println("--- LOG IN ---");
                System.out.print("Username: ");
                String tryUserName = sc.nextLine();
                System.out.print("Password: ");
                String tryPassWord = sc.nextLine();
                
                boolean loginSuccess = false;
                for(Person p : people){
                    if(p.getUserName().equals(tryUserName) && p.getPassWord().equals(tryPassWord)){
                        System.out.println("\nWelcome " + p.getFirstName() + ", " + p.getLastName() + " it is great to see you again.");
                        loginSuccess = true;
                        break;
                    }
                }
                
                if(!loginSuccess){
                    System.out.println("\nUsername or password incorrect, please try again.");
                }
            }
            else if(pick == 2){
                // check if any users exist
                if(people.isEmpty()){
                    System.out.println("\nNo accounts yet. Register  first.");
                    continue;
                }
                
                System.out.println("\n--- LOG IN ---");
                System.out.print("Username: ");
                String tryUserName = sc.nextLine();
                System.out.print("Password: ");
                String tryPassWord = sc.nextLine();
                
                // find matching user
                boolean loginSuccess = false;
                for(Person p : people){
                    if(p.getUserName().equals(tryUserName) && p.getPassWord().equals(tryPassWord)){
                        System.out.println("\nWelcome " + p.getFirstName() + ", " + p.getLastName() + " it is great to see you again.");
                        loginSuccess = true;
                        break;
                    }
                }
                
                if(!loginSuccess){
                    System.out.println("\nUsername or password incorrect, please try again.");
                }
            }
            
            else if(pick == 3){
                System.out.println("\n GOODBYE!");
                break;
            }
            else{
                System.out.println("\nWrong choice. Pick 1,2 or 3.");
            }
        }
        sc.close();
    }
}